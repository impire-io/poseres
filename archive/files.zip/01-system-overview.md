# 01 — System Overview

This document is the map of the system: its parts, how they connect, the loop they run, and how the system starts and stops. Every component named here is specified in detail in a later document.

---

## 1. What the system is

A continuously-learning intelligence composed of:

- a **body** — a configurable set of sensors and actuators (the anatomy);
- a **sensorimotor core** — reference frames that build and continuously refine a model of the world from sensorimotor experience;
- a **structural-learning process** — that grows, prunes, and reshapes the frame population over time;
- a **motivation layer** — a fixed innate drive that produces the system's only notion of "better," from which the system discovers its own goals;
- an **action layer** — that selects actions to satisfy the drive;
- a **persistence layer** — that snapshots the entire evolving state so it can be restored.

The system runs in a continuous loop: sense, interpret, learn, evaluate against the drive, act. Structural change and snapshotting happen periodically during a consolidation phase.

It has no fixed task. It is configured with a body and a drive, and it learns whatever its experience and drive lead it to. **[D]**

---

## 2. Component map

```
                          ┌─────────────────────────────────────────┐
                          │                 BODY                     │
        world  ───────▶   │  Sensors  ──────────────▶  observations  │
          ▲               │  Actuators ◀── actions                   │
          │               └─────────────────────────────────────────┘
          │                        │ observations                 ▲ actions
          │                        ▼                               │
          │               ┌──────────────────┐                    │
          │               │       BUS         │  sensorimotor      │
          │               │  (delivery)       │  events            │
          │               └──────────────────┘                    │
          │                        │ broadcast                     │
          │                        ▼                               │
          │        ┌───────────────────────────────┐              │
          │        │      SENSORIMOTOR CORE          │             │
          │        │  Reference frames (SIMD)        │             │
          │        │  → local poses, global pose     │             │
          │        │  → recon / prediction / effort  │             │
          │        └───────────────────────────────┘              │
          │             │ measurements        │ poses, transitions │
          │             ▼                     ▼                    │
          │   ┌──────────────────┐   ┌──────────────────┐         │
          │   │ STRUCTURAL        │   │  MOTIVATION       │        │
          │   │ LEARNING          │   │  Innate drive     │        │
          │   │ spawn/select/decay│   │  → value signal   │        │
          │   └──────────────────┘   └──────────────────┘         │
          │             │                     │ value             │
          │             │                     ▼                   │
          │             │            ┌──────────────────┐         │
          │             │            │   ACTION          │ ────────┘
          │             │            │   policy          │
          │             │            └──────────────────┘
          │             ▼
          │   ┌──────────────────────────────────────────┐
          └── │            PERSISTENCE                     │
              │  snapshot / restore the whole state        │
              └──────────────────────────────────────────┘
```

---

## 3. The runtime loop

The system runs two interleaved loops.

### 3.1 The fast loop (per sensorimotor step) — **[D]**, with **[V]** core

Executed continuously, once per interaction with the world:

1. **Sense.** Sensors produce an `observation`. (Doc 02)
2. **Deliver.** The bus broadcasts a sensorimotor event to every frame. (Doc 02)
3. **Interpret & learn (online).** Each frame decides to map or drop the observation; mapping frames place it at a local pose, learn from it, and produce measurements (reconstruction error, prediction error, effort). The set of local poses is the global pose. (Doc 03)
4. **Evaluate.** The motivation layer computes the current value signal from the frames' measurements and from observation novelty. (Doc 05)
5. **Act.** The action layer selects an action that is expected to increase the value signal, using the frames' transition models to anticipate consequences. (Doc 05)
6. **Actuate.** The chosen action is sent to the actuators, changing the world. (Doc 02)

Structure is fixed during the fast loop, except that a frame is **born on demand** if no frame maps an observation (Doc 04).

### 3.2 The slow loop (consolidation phase) — **[V]** mechanism, **[D]** scheduling

Executed periodically (configurable cadence; conceptually "sleep"):

1. **Restructure.** Spawn candidate frames, evict frames that have not earned their place, age the population. (Doc 04)
2. **Snapshot.** Persist the full system state. (Doc 06)

The two loops do not run concurrently on the same state: the slow loop runs while the fast loop is paused, so structural change and snapshots are taken on a consistent, point-in-time state.

---

## 4. Lifecycle

### 4.1 Boot — **[D]**

The system starts in one of two ways:

- **Fresh boot.** Given a configuration (Doc 07) that declares the anatomy (Doc 02) and the innate drive (Doc 05), the system starts with an **empty frame population** (zero-start). Frames are born as observations arrive. (Doc 04)
- **Restore.** Given a snapshot (Doc 06), the system reconstructs its entire state — frame population, drive state, policy state, counters — and resumes the fast loop from a consistent point.

### 4.2 Run

The system runs the fast loop continuously, interrupting periodically for the slow loop. It runs indefinitely.

### 4.3 Stop

The system **MUST** be stoppable only at a consistent point (between fast-loop steps or during the slow loop), and **MUST** take a final snapshot on a clean stop so it can be restored.

---

## 5. Cross-cutting requirements (apply to every component)

- **C1 — Homogeneous, vectorized frames.** All reference frames run one identical computational kernel; frames are evaluated in batches grouped by dimensionality (the SIMD requirement). No per-frame branching. Detailed in Doc 03. **[V]**
- **C2 — Component isolation.** The Bus, the Scorer, the structural-learning policies, the Drive, the Policy, and the Storage backend are each a single replaceable component behind an interface. Swapping any one **MUST NOT** require edits to the others. **[D]**
- **C3 — Fixed innate drive.** The innate (terminal) drive is set at configuration and **MUST NOT** be modifiable by the running system. Only instrumental goals and learned parameters change at runtime. Detailed in Doc 05. **[D]**
- **C4 — Consistent state.** The complete system state is always serializable at any consolidation point, with no in-flight partial updates. Detailed in Doc 06. **[D]**
- **C5 — Configurability.** Anatomy and drive are supplied by configuration at boot. Detailed in Docs 02, 05, 07. **[D]**

---

## 6. Glossary

| Term | Meaning |
|---|---|
| **Body / anatomy** | The configured set of sensors and actuators. |
| **Sensor** | A source of observations. |
| **Actuator** | A sink for actions; changes the world or the body. |
| **Tool** | A sensor or actuator added beyond the base anatomy, possibly at runtime. |
| **Observation** | A fixed-length real vector produced by sensing. |
| **Action** | A command issued to actuators, drawn from the configured action space. |
| **Sensorimotor event** | The unit on the bus: previous observation, action taken, resulting observation. |
| **Reference frame (frame)** | A learnable dimensioned coordinate space with an encoder, decoder, and per-action transition model. Holds many concepts. |
| **Local pose** | The coordinate a single frame assigns to an observation. |
| **Global pose** | The set of local poses from all frames that mapped an observation; the system's interpretation. |
| **Transition** | A frame's learned map from (pose, action) to predicted next pose. |
| **Reconstruction error** | How poorly a frame reconstructs an observation from its pose (the *explanatory* measurement). |
| **Prediction error** | How poorly a frame's transition predicts the next pose (the *predictive* measurement). |
| **Effort** | The magnitude of the displacement a transition predicts (the *regularizing* measurement). |
| **Survival score** | The combined quantity used to keep or evict a frame; lower is better. |
| **Online learning** | Weight changes within fixed structure, during the fast loop. |
| **Structural learning** | Birth, eviction, and re-dimensioning of frames, during the slow loop. |
| **Candidate** | A newly spawned frame, protected from eviction until it has had exposure. |
| **Innate / terminal drive** | The fixed value the system is wired to pursue; not self-modifiable. |
| **Instrumental goal** | A learned, revisable sub-goal the system discovers serves its drive. |
| **Value signal** | The scalar the drive produces, used by the action layer. |
| **Snapshot** | A serialized point-in-time copy of the entire system state. |

---

## 7. Definition of done (system level)

The system is complete when:
1. It boots fresh from a configuration declaring anatomy and drive, with an empty frame population.
2. It runs the fast loop continuously and the slow loop periodically, as specified in Docs 02–05.
3. Frames are homogeneous and SIMD-batched per C1 and Doc 03.
4. The innate drive is fixed per C3 and produces a value signal that the action layer consumes (Doc 05).
5. The full state can be snapshotted and restored to a consistent point per C4 and Doc 06.
6. Every component in C2 is independently replaceable.
7. Every configuration parameter in Doc 07 is exposed.

Per-component "done" criteria are given in each component's document.
